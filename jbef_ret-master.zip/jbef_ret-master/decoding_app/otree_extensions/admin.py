from decoding_app.views import  AllSessionsList

data_export_views = [ AllSessionsList]
