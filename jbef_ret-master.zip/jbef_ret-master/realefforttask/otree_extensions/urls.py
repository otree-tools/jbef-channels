# from django.conf.urls import url, include
# from realefforttask import pages as v
#
#
# urlpatterns = []
# view_classes = [v.PPPUpdateView,]
#
# # to protect if auth level
# for ViewCls in view_classes:
#     as_view = ViewCls.as_view()
#     urlpatterns.append(url(ViewCls.url_pattern, as_view, name=ViewCls.url_name))